<div class="no-record-found">
    {!! isset( $no_records_data )? $no_records_data : '' !!}
    <span class="rurera-no-records">No Records Found</span>
</div>