<svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24">
    <g id="Mask_Group_18" clip-path="url(#clip-path)" data-name="Mask Group 18" transform="translate(-25 -410)">
        <g id="task" transform="translate(25 410)">
            <path id="Path_156" d="M8.227 6.8h-3.75a.7.7 0 0 0 0 1.406h3.75a.7.7 0 0 0 0-1.406z" class="cls-3" data-name="Path 156"/>
            <path id="Path_157" d="M8.227 10.547h-3.75a.7.7 0 0 0 0 1.406h3.75a.7.7 0 0 0 0-1.406z" class="cls-3" data-name="Path 157"/>
            <path id="Path_158" d="M8.227 14.3h-3.75a.7.7 0 0 0 0 1.406h3.75a.7.7 0 0 0 0-1.406z" class="cls-3" data-name="Path 158"/>
            <path id="Path_159" d="M18.3 12.887V6.468a3.5 3.5 0 0 0-1-2.462l-2.853-2.95A3.538 3.538 0 0 0 11.934 0H2.883a2.112 2.112 0 0 0-2.11 2.109v18.235a2.112 2.112 0 0 0 2.109 2.109H13.75a5.589 5.589 0 1 0 4.55-9.566zM2.18 20.344V2.109a.7.7 0 0 1 .7-.7h9.051a2.124 2.124 0 0 1 1.5.629l2.852 2.95a2.1 2.1 0 0 1 .617 1.48v6.42a5.576 5.576 0 0 0-4.217 8.159h-9.8a.7.7 0 0 1-.7-.7zm15.42 2.25a4.172 4.172 0 1 1 4.219-4.172 4.177 4.177 0 0 1-4.219 4.172z" class="cls-3" data-name="Path 159"/>
            <path id="Path_160" d="M19.224 16.757a.7.7 0 0 0-.99.09l-1.187 1.424-.269-.538a.7.7 0 0 0-1.258.629l.75 1.5a.7.7 0 0 0 .548.384.716.716 0 0 0 .081 0 .7.7 0 0 0 .54-.253l1.875-2.25a.7.7 0 0 0-.09-.986z" class="cls-3" data-name="Path 160"/>
            <path id="Path_161" d="M11.977 8.2h.75a.7.7 0 0 0 0-1.406h-.75a.7.7 0 0 0 0 1.406z" class="cls-3" data-name="Path 161"/>
            <path id="Path_162" d="M13.43 11.25a.7.7 0 0 0-.7-.7h-.75a.7.7 0 0 0 0 1.406h.75a.7.7 0 0 0 .7-.706z" class="cls-3" data-name="Path 162"/>
        </g>
    </g>
</svg>
