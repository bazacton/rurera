<svg xmlns="http://www.w3.org/2000/svg" width="24.043" height="24.043" viewBox="0 0 24.043 24.043">
    <g id="Group_1282" transform="translate(-208.957 -447.957)">
        <g id="browser" transform="translate(208.957 447.957)">
            <g id="Group_1269">
                <g id="Group_1268">
                    <path id="Path_1557" d="M21.93 0H2.113A2.116 2.116 0 0 0 0 2.113V21.93a2.116 2.116 0 0 0 2.113 2.113H21.93a2.116 2.116 0 0 0 2.113-2.113V2.113A2.116 2.116 0 0 0 21.93 0zm.7 21.93a.705.705 0 0 1-.7.7H2.113a.705.705 0 0 1-.7-.7V7.044h21.222zm0-16.3H1.409V2.113a.705.705 0 0 1 .7-.7H21.93a.705.705 0 0 1 .7.7z" class="cls-1"/>
                </g>
            </g>
            <g id="Group_1271" transform="translate(1.906 1.906)">
                <g id="Group_1270">
                    <circle id="Ellipse_222" cx="1" cy="1" r="1" class="cls-1" transform="translate(.137 .137)"/>
                </g>
            </g>
            <g id="Group_1273" transform="translate(5.227 1.906)">
                <g id="Group_1272">
                    <circle id="Ellipse_223" cx="1" cy="1" r="1" class="cls-1" transform="translate(-.183 .137)"/>
                </g>
            </g>
            <g id="Group_1275" transform="translate(10.761 16.296)">
                <g id="Group_1274">
                    <circle id="Ellipse_224" cx="1" cy="1" r="1" class="cls-1" transform="translate(.282 -.252)"/>
                </g>
            </g>
            <g id="Group_1277" transform="translate(8.453 2.818)">
                <g id="Group_1276">
                    <path id="Path_1558" d="M192.069 60H180.7a.7.7 0 1 0 0 1.409h11.364a.7.7 0 0 0 0-1.409z" class="cls-1" transform="translate(-180 -60)"/>
                </g>
            </g>
            <g id="Group_1279" transform="translate(5.635 8.453)">
                <g id="Group_1278">
                    <path id="Path_1559" d="M126.387 180a6.455 6.455 0 0 0-6.387 6.434 6.387 6.387 0 0 0 12.773 0 6.455 6.455 0 0 0-6.386-6.434zm0 11.364a4.96 4.96 0 0 1-4.978-4.931 4.978 4.978 0 1 1 9.955 0 4.96 4.96 0 0 1-4.977 4.931z" class="cls-1" transform="translate(-120 -180)"/>
                </g>
            </g>
            <g id="Group_1281" transform="translate(11.317 11.27)">
                <g id="Group_1280">
                    <path id="Path_1560" d="M241.7 240a.7.7 0 0 0-.7.7v2.912a.7.7 0 0 0 1.409 0V240.7a.7.7 0 0 0-.709-.7z" class="cls-1" transform="translate(-241 -240)"/>
                </g>
            </g>
        </g>
    </g>
</svg>
