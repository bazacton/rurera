@extends('web.default.panel.layouts.panel_layout')
@php use App\Models\Webinar; @endphp

@section('content')
<h3>You dont have sufficient game time to play this game!</h3>
@endsection

@push('scripts_bottom')
@endpush
