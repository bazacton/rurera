@php
    $percent = $course->getProgress(true);
@endphp


