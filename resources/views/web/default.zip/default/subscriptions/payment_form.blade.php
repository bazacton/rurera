@include('web.default.subscriptions.steps',['activeStep'=> 'payment'])
@php $subscribed_for_months = (isset( $subscribed_for ) && $subscribed_for == 12)? 12 : 1;
$subscribed_for_label = ($subscribed_for_months == 12)? 'Year' : 'Month';

$discount_percentage = ($subscribed_for_months == 12)? 25 : 0;
$selected_package_price = $packageObj->price*$subscribed_for_months;


$discounted_amount = ($selected_package_price*$discount_percentage) / 100;
$selected_package_price = $selected_package_price-$discounted_amount;

@endphp
<style>


.hidden {
  display: none;
}

#payment-message {
  color: rgb(105, 115, 134);
  font-size: 16px;
  line-height: 20px;
  padding-top: 12px;
  text-align: center;
}

#payment-element {
  margin-bottom: 24px;
}

/* Buttons and links */
button {
    border: 0;
    padding: 12px 16px;
    font-weight: 600;
    transition: all 0.2s ease;
    box-shadow: 0px 4px 5.5px 0px rgba(0, 0, 0, 0.07);
    width: 100%;
}
button:hover {
  filter: contrast(115%);
}
button:disabled {
  opacity: 0.5;
  cursor: default;
}


@-webkit-keyframes loading {
  0% {
    -webkit-transform: rotate(0deg);
    transform: rotate(0deg);
  }
  100% {
    -webkit-transform: rotate(360deg);
    transform: rotate(360deg);
  }
}
@keyframes loading {
  0% {
    -webkit-transform: rotate(0deg);
    transform: rotate(0deg);
  }
  100% {
    -webkit-transform: rotate(360deg);
    transform: rotate(360deg);
  }
}
</style>

<div class="payment-options-holder panel-border bg-white rounded-sm p-25 mb-40 mt-30">
    <div class="selected-plan-data mb-40">
        <div class="row">
            <div class="col-12 col-lg-12 col-md-12">
                <div class="text-box">
                    <h2 class="font-22 mb-20">Selected Plan</h2>
                    <h5 class="mb-10">{{$packageObj->title}}</h5>
                    <p class="mb-10">Text here</p>
                    <div class="package-price mb-25" data-price_amount="{{$packageObj->price*$subscribed_for_months}}"><strong>{{ addCurrencyToPrice(($selected_package_price)) }}</strong> / {{$subscribed_for_label}}</div>
                    <div class="packages-back-btn font-weight-500 mb-15 font-15" data-subscribed_for="{{$subscribed_for_months}}" data-user_id="{{$user_id}}">Change Package</div>
                </div>
            </div>
        </div>
    </div>

    <div class="row discount-code-block">
        <div class="col-12 col-lg-12 col-md-12 col-sm-12">
            <div class="book-form">
                <div class="row">
                    <div class="col-12 col-lg-9 col-md-9 col-sm-12">
                        <div class="form-group">
                            <p>Have a discount code?</p>
                            <div class="input-field"><input type="text" class="coupon_code" placeholder="Enter Code"/></div>
                        </div>
                    </div>
                    <div class="col-12 col-lg-3 col-md-3 col-sm-12">
                        <a href="javascript:;" class="nav-link btn-primary rounded-pill coupon-code-apply">Apply</a>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <div class="book-form-holder">
        <div class="container">
        <div class="card-gateway-fields-holder">
            <h2 class="font-22 mb-15">Payment details</h2>
            <div class="row mb-10">
                <div class="col-12 col-lg-12 col-md-12 col-sm-12">
                    @if( isset( $subscribed_childs ) && $subscribed_childs == 0)
                    <p>No need to worry! We won't ask for payment until after your 7-day free trial ends.</p>
                    @endif
                    <p>By proceeding, you let rurera.com charge from your card for future payments as per their <a href="/terms-and-conditions">terms and conditions</a>.</p>
					<br><br>
					<p>After submission, you will be redirected to securely complete next steps.</p>
					<div class="col-12 col-lg-12 col-md-12 col-sm-12 text-center"><a href="javascript:;" data-user_id="{{isset($user_id)? $user_id : 0}}" data-subscribed_for="{{isset($subscribed_for)? $subscribed_for : 0}}" class="nav-link btn-primary rounded-pill mb-25 process-payment">Take me to Payment</a></div>
                </div>
                <div class="col-12 col-lg-12 col-md-12 col-sm-12 rurera-hide">
                <form id="payment-form">
                      <div id="payment-element">
                        <!--Stripe.js injects the Payment Element-->
                      </div>
                      <button id="submit" class="btn-primary mb-25">
                        <div class="spinner hidden" id="spinner"></div>
                        <span id="button-text">Pay now</span>
                      </button>
                      <div id="payment-message" class="hidden"></div>
                    </form>
                </div>
                <div class="col-12 col-lg-12 col-md-12 col-sm-12  rurera-hide">
                    <div class="book-form mt-30">
                        <div class="row">
                            <div class="col-12 col-lg-12 col-md-12">
                                <ul class="tests-list payment-methods mb-15">
                                    <li data-type="card-gateway" class="active"><img src="/assets/default/svgs/card-credit.svg" alt=""> Card</li>
                                    <li data-type="googlepay-gateway" class="process-payment1" data-user_id="{{isset($user_id)? $user_id : 0}}" data-subscribed_for="{{isset($subscribed_for)? $subscribed_for : 0}}"><img src="/assets/default/svgs/stripe-pay.svg" class="google-icon" alt=""> Pay with Stipe</li>
                                </ul>
                            </div>
                            <div class="card-gateway-fields conditional-fields row">




                                <div class="col-12 col-lg-6 col-md-6 col-sm-12">
                                    <div class="form-group">
                                        <div class="input-field"><input type="text" placeholder="First Name"/></div>
                                    </div>
                                </div>
                                <div class="col-12 col-lg-6 col-md-6 col-sm-12">
                                    <div class="form-group">
                                        <div class="input-field"><input type="text" placeholder="Last Name"/></div>
                                    </div>
                                </div>
                                <div class="col-12 col-lg-6 col-md-6 col-sm-12">
                                    <span class="form-label">Card Number</span>
                                    <div class="form-group">
                                        <div class="input-field input-card">
                                            <span class="icon-svg">
                                                <svg
                                                        version="1.1"
                                                        id="_x32_"
                                                        xmlns="http://www.w3.org/2000/svg"
                                                        xmlns:xlink="http://www.w3.org/1999/xlink"
                                                        width="64px"
                                                        height="64px"
                                                        viewBox="0 0 512 512"
                                                        xml:space="preserve"
                                                        fill="#000000"
                                                >
                                                    <g id="SVGRepo_bgCarrier" stroke-width="0"></g>
                                                    <g id="SVGRepo_tracerCarrier" stroke-linecap="round" stroke-linejoin="round"></g>
                                                    <g id="SVGRepo_iconCarrier">
                                                        <g>
                                                            <path
                                                                    class="st0"
                                                                    d="M261.031,153.484h-5.375v7.484h5.375c1.25,0,2.266-0.344,3-1.031c0.766-0.688,1.156-1.594,1.156-2.719 c0-1.109-0.391-2-1.156-2.703C263.297,153.828,262.281,153.484,261.031,153.484z"
                                                            ></path>
                                                            <path
                                                                    class="st0"
                                                                    d="M140.75,169.141c0.141-0.391,0.281-0.891,0.344-1.453c0.094-0.578,0.141-1.266,0.172-2.078 c0.031-0.797,0.031-1.766,0.031-2.891c0-1.109,0-2.063-0.031-2.875s-0.078-1.5-0.172-2.078c-0.063-0.578-0.203-1.047-0.344-1.453 c-0.156-0.406-0.375-0.75-0.641-1.078c-0.953-1.172-2.359-1.75-4.266-1.75H131.5v18.484h4.344c1.906,0,3.313-0.594,4.266-1.75 C140.375,169.891,140.594,169.531,140.75,169.141z"
                                                            ></path>
                                                            <path
                                                                    class="st0"
                                                                    d="M88.219,159.938c0.75-0.688,1.141-1.594,1.141-2.719c0-1.109-0.391-2-1.141-2.703 c-0.75-0.688-1.75-1.031-3.016-1.031h-5.375v7.484h5.375C86.469,160.969,87.469,160.625,88.219,159.938z"
                                                            ></path>
                                                            <polygon class="st0" points="229.875,167.219 237.141,167.219 233.563,156.906 "></polygon>
                                                            <path
                                                                    class="st0"
                                                                    d="M466.656,88H45.344C20.313,88,0,108.313,0,133.344v245.313C0,403.688,20.313,424,45.344,424h421.313 C491.688,424,512,403.688,512,378.656V133.344C512,108.313,491.688,88,466.656,88z M435.656,138.313 c12.344,0,22.344,10,22.344,22.344S448,183,435.656,183s-22.344-10-22.344-22.344S423.313,138.313,435.656,138.313z M375.875,138.313c12.344,0,22.344,10,22.344,22.344S388.219,183,375.875,183s-22.344-10-22.344-22.344 S363.531,138.313,375.875,138.313z M276.781,148.531h10.547c2,0,3.703,0.344,5.141,1c1.406,0.672,2.625,1.719,3.688,3.156 c0.438,0.609,0.781,1.25,1.031,1.938c0.266,0.672,0.469,1.406,0.563,2.219s0.188,1.703,0.203,2.672 c0.031,0.969,0.047,2.047,0.047,3.203c0,1.172-0.016,2.25-0.047,3.219c-0.016,0.969-0.109,1.844-0.203,2.656 s-0.297,1.563-0.563,2.234c-0.25,0.672-0.594,1.328-1.031,1.938c-1.063,1.422-2.281,2.484-3.688,3.141 c-1.438,0.672-3.141,1-5.141,1h-10.547V148.531z M197.391,159.063c0.047-1.094,0.156-2.094,0.328-3.016 c0.188-0.922,0.469-1.766,0.859-2.516c0.406-0.781,0.969-1.531,1.703-2.25c1.016-0.938,2.156-1.688,3.406-2.203 c1.266-0.516,2.75-0.766,4.438-0.766c2.734,0,5.063,0.75,7,2.25s3.156,3.719,3.703,6.703H213c-0.281-1.172-0.813-2.141-1.594-2.891 s-1.875-1.125-3.281-1.125c-0.781,0-1.5,0.125-2.109,0.391c-0.625,0.266-1.125,0.625-1.547,1.078c-0.281,0.281-0.5,0.625-0.672,1 s-0.328,0.844-0.438,1.438c-0.109,0.578-0.203,1.313-0.234,2.203c-0.063,0.891-0.094,2.016-0.094,3.359 c0,1.359,0.031,2.484,0.094,3.375c0.031,0.891,0.125,1.625,0.234,2.219c0.109,0.563,0.266,1.063,0.438,1.422 c0.172,0.375,0.391,0.703,0.672,1c0.422,0.453,0.922,0.797,1.547,1.078c0.609,0.25,1.328,0.391,2.109,0.391 c1.406,0,2.531-0.375,3.297-1.141c0.797-0.75,1.328-1.719,1.625-2.875h5.781c-0.547,2.969-1.766,5.203-3.703,6.703 c-1.938,1.516-4.266,2.266-7,2.266c-1.688,0-3.172-0.281-4.438-0.781c-1.25-0.531-2.391-1.266-3.406-2.219 c-0.734-0.719-1.297-1.469-1.703-2.219c-0.391-0.781-0.672-1.625-0.859-2.531c-0.172-0.922-0.281-1.938-0.328-3.016 c-0.031-1.094-0.063-2.313-0.063-3.672C197.328,161.375,197.359,160.156,197.391,159.063z M163.172,148.531h20.969v4.953h-7.625 v23.422h-5.703v-23.422h-7.641V148.531z M152.844,148.531h5.688v28.375h-5.688V148.531z M125.797,148.531h10.547 c2,0,3.688,0.344,5.125,1c1.422,0.672,2.656,1.719,3.688,3.156c0.438,0.609,0.781,1.25,1.047,1.938 c0.266,0.672,0.453,1.406,0.563,2.219s0.172,1.703,0.203,2.672s0.031,2.047,0.031,3.203c0,1.172,0,2.25-0.031,3.219 s-0.094,1.844-0.203,2.656s-0.297,1.563-0.563,2.234s-0.609,1.328-1.047,1.938c-1.031,1.422-2.266,2.484-3.688,3.141 c-1.438,0.672-3.125,1-5.125,1h-10.547V148.531z M100.969,148.531h19.219v4.953h-13.531v6.641h11.531v4.953h-11.531v6.891h13.531 v4.938h-19.219V148.531z M74.125,148.531h11.453c1.484,0,2.797,0.25,3.969,0.703c1.172,0.469,2.172,1.094,3,1.875 s1.453,1.703,1.859,2.75c0.438,1.047,0.656,2.172,0.656,3.359c0,1.016-0.156,1.922-0.438,2.719c-0.297,0.797-0.688,1.5-1.156,2.125 c-0.5,0.625-1.063,1.156-1.719,1.594c-0.641,0.438-1.313,0.781-2.031,1.016l6.531,12.234h-6.625l-5.688-11.313h-4.109v11.313 h-5.703V148.531z M60.344,285.75v-21.875h33.25v21.875H60.344z M93.594,292.75v23.625H75.219c-8.219,0-14.875-6.656-14.875-14.875 v-8.75H93.594z M60.344,256.875V235h33.25v21.875H60.344z M60.344,228v-8.75c0-8.219,6.656-14.875,14.875-14.875h18.375V228H60.344 z M47.688,162.719c0-1.344,0.031-2.563,0.063-3.656c0.047-1.094,0.156-2.094,0.344-3.016c0.172-0.922,0.469-1.766,0.844-2.516 c0.406-0.781,0.969-1.531,1.719-2.25c1-0.938,2.125-1.688,3.406-2.203c1.25-0.516,2.734-0.766,4.422-0.766 c2.734,0,5.078,0.75,7.016,2.25c1.922,1.5,3.141,3.719,3.688,6.703h-5.813c-0.297-1.172-0.828-2.141-1.594-2.891 c-0.781-0.75-1.875-1.125-3.297-1.125c-0.797,0-1.484,0.125-2.109,0.391s-1.125,0.625-1.531,1.078c-0.281,0.281-0.5,0.625-0.688,1 c-0.172,0.375-0.313,0.844-0.438,1.438c-0.109,0.578-0.188,1.313-0.234,2.203s-0.078,2.016-0.078,3.359 c0,1.359,0.031,2.484,0.078,3.375s0.125,1.625,0.234,2.219c0.125,0.563,0.266,1.063,0.438,1.422c0.188,0.375,0.406,0.703,0.688,1 c0.406,0.453,0.906,0.797,1.531,1.078c0.625,0.25,1.313,0.391,2.109,0.391c1.422,0,2.531-0.375,3.297-1.141 c0.797-0.75,1.328-1.719,1.625-2.875h5.781c-0.547,2.969-1.766,5.203-3.688,6.703c-1.938,1.516-4.281,2.266-7.016,2.266 c-1.688,0-3.172-0.281-4.422-0.781c-1.281-0.531-2.406-1.266-3.406-2.219c-0.75-0.719-1.313-1.469-1.719-2.219 c-0.375-0.781-0.672-1.625-0.844-2.531c-0.188-0.922-0.297-1.938-0.344-3.016C47.719,165.297,47.688,164.078,47.688,162.719z M128,370.656H48v-16h80V370.656z M132.094,228v7v9.031v0.594v12.25v7v9.625v5.531v6.719v7v13.406v10.219h-31.5v-10.219V292.75v-7 v-6.719V273.5v-9.625v-7v-12.25v-0.594V235v-7v-7.594v-16.031h18.375h13.125h5.25h16.625h3.484c8.219,0,14.891,6.656,14.891,14.875 V228h-18.375h-16.625H132.094z M139.094,256.875V235h33.25v21.875H139.094z M172.344,263.875v21.875h-33.25v-21.875H172.344z M139.094,316.375V292.75h33.25v8.75c0,8.219-6.672,14.875-14.891,14.875H139.094z M240,370.656h-80v-16h80V370.656z M240.375,176.906l-1.719-5.016h-10.375l-1.781,5.016h-5.938l10.625-28.375h4.469l10.688,28.375H240.375z M259.75,165.594h-4.094 v11.313h-5.703v-28.375h11.453c1.469,0,2.797,0.25,3.969,0.703c1.172,0.469,2.172,1.094,3,1.875 c0.813,0.781,1.438,1.703,1.859,2.75c0.438,1.047,0.641,2.172,0.641,3.359c0,1.016-0.141,1.922-0.438,2.719 c-0.281,0.797-0.672,1.5-1.156,2.125c-0.5,0.625-1.063,1.156-1.703,1.594s-1.328,0.781-2.047,1.016l6.531,12.234h-6.609 L259.75,165.594z M352,370.656h-80v-16h80V370.656z M464,370.656h-80v-16h80V370.656z M464,322.656H304v-16h160V322.656z"
                                                            ></path>
                                                            <path
                                                                    class="st0"
                                                                    d="M291.75,169.141c0.125-0.391,0.266-0.891,0.344-1.453c0.078-0.578,0.125-1.266,0.156-2.078 c0.031-0.797,0.031-1.766,0.031-2.891c0-1.109,0-2.063-0.031-2.875s-0.078-1.5-0.156-2.078s-0.219-1.047-0.344-1.453 c-0.156-0.406-0.375-0.75-0.656-1.078c-0.938-1.172-2.375-1.75-4.266-1.75h-4.344v18.484h4.344c1.891,0,3.328-0.594,4.266-1.75 C291.375,169.891,291.594,169.531,291.75,169.141z"
                                                            ></path>
                                                        </g>
                                                    </g>
                                                </svg>
                                            </span>
                                            <input type="text" placeholder="Card Number"/>
                                        </div>
                                    </div>
                                </div>
                                <div class="col-12 col-lg-6 col-md-6 col-sm-12">
                                <div class="row">
                                        <div class="col-12 col-lg-6 col-md-6 col-sm-12">
                                            <span class="form-label">Expiry</span>
                                            <div class="form-group">
                                                <div class="input-field">
                                                    <input type="text" placeholder="MM / YY">
                                                </div>

                                            </div>
                                        </div>
                                        <div class="col-12 col-lg-6 col-md-6 col-sm-12">
                                            <span class="form-label">CVC</span>
                                            <div class="form-group">
                                                <div class="input-field">
                                                    <input type="text" placeholder="CVC">
                                                </div>

                                            </div>
                                        </div>
                                </div>
                                </div>
                                <div class="col-12 col-lg-6 col-md-6 col-sm-12">
                                    <span class="form-label">Country</span>
                                    <div class="form-group">
                                        <div class="select-box">
                                            <select>
                                                <option value="United Kingdom">United Kingdom</option>
                                                <option value="USA">USA</option>
                                                <option value="France">France</option>
                                            </select>
                                        </div>
                                    </div>
                                </div>
                                <div class="col-12 col-lg-6 col-md-6 col-sm-12">
                                    <span class="form-label">Postel Code</span>
                                    <div class="form-group">
                                        <div class="input-field">
                                            <input type="text" placeholder="WS11 1DB">
                                        </div>
                                    </div>
                                </div>

                            <div class="col-12 col-lg-12 col-md-12 col-sm-12 text-center">
                                @if( isset( $subscribed_childs ) && $subscribed_childs == 0)
                                <p class="mb-25">
                                    Once your 7-day free trial is over, we will automatically charge your chosen payment method ${{$payment_amount}} every month until you decide to cancel. You have the freedom to
                                    cancel at any time.
                                    Keep in mind that there may be sales tax added. For instructions on how to cancel, please refer to the provided guidelines
                                </p>
                                @endif
                            </div>
                            <div class="col-12 col-lg-12 col-md-12 col-sm-12 text-center"><a href="javascript:;" data-user_id="{{isset($user_id)? $user_id : 0}}" data-subscribed_for="{{isset($subscribed_for)? $subscribed_for : 0}}" class="nav-link btn-primary rounded-pill mb-25 process-payment">Sart Free Trial</a></div>
                            <div class="col-12 col-lg-12 col-md-12 col-sm-12 text-center">
                                <p class="mb-20">By Clicking on Start Free Trial, I agree to the<a href="#">Terms of Service</a>And<a href="#">Privacy Policy</a></p>
                                <div class="secure-server">
                                    <figure>
                                        <svg fill="#000000" width="64px" height="64px" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg" id="lock-check" class="icon glyph">
                                            <g id="SVGRepo_bgCarrier" stroke-width="0"></g>
                                            <g id="SVGRepo_tracerCarrier" stroke-linecap="round" stroke-linejoin="round"></g>
                                            <g id="SVGRepo_iconCarrier">
                                                <path
                                                        d="M18,8H17V7A5,5,0,0,0,7,7V8H6a2,2,0,0,0-2,2V20a2,2,0,0,0,2,2H18a2,2,0,0,0,2-2V10A2,2,0,0,0,18,8ZM9,7a3,3,0,0,1,6,0V8H9Zm6.71,6.71-4,4a1,1,0,0,1-1.42,0l-2-2a1,1,0,0,1,1.42-1.42L11,15.59l3.29-3.3a1,1,0,0,1,1.42,1.42Z"
                                                ></path>
                                            </g>
                                        </svg>
                                    </figure>
                                    <span>
                                        Secure Server<br/>
                                        SSL Encrypted
                                    </span>
                                </div>
                            </div>
                            </div>
							

                            <div class="googlepay-gateway-fields conditional-fields rurera-hide payment-content p-25">
                                @if( isset( $subscribed_childs ) && $subscribed_childs == 0)
                                <p class="mb-25">
                                    Once your 7-day free trial is over, we will automatically charge your chosen payment method $5 every month until you decide to cancel. You have the freedom to
                                    cancel at any time.
                                    Keep in mind that there may be sales tax added. For instructions on how to cancel, please refer to the provided guidelines
                                </p>
                                @endif











                                <div class="col-12 col-lg-12 col-md-12 col-sm-12 text-center"><a href="javascript:;" data-user_id="{{isset($user_id)? $user_id : 0}}" data-subscribed_for="{{isset($subscribed_for)? $subscribed_for : 0}}" class="nav-link btn-primary rounded-pill mb-25 process-payment">Take me to Stripe Site</a></div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>



        </div>
    </div>
</div>


<script>



	$(document).on('click', '.coupon-code-apply', function (e) {
		var thisObj = $(this);
		rurera_loader(thisObj, 'div');
        var coupon_code = $('.coupon_code').val();
		var package_price = $(".package-price").attr('data-price_amount');
        if( coupon_code != ''){
			$.ajax({
				type: "GET",
				url: '/subscribes/get-coupon-data',
				data: {"coupon_code": coupon_code, "package_price": package_price},
				success: function (return_data) {
					return_data = JSON.parse(return_data);
					$(".package-price strong").html(return_data.package_price_full);
					rurera_remove_loader(thisObj, 'div');
				}
			});
		}
    });
	
    $(document).on('click', '.payment-methods li', function (e) {
        var gateway_type = $(this).attr('data-type');
        $(".payment-methods li").removeClass('active');
        $(this).addClass('active');
        $(".conditional-fields").addClass('rurera-hide');
        $('.'+gateway_type+"-fields").removeClass('rurera-hide');
    });

    // This is your test publishable API key.
    const stripe = Stripe('{{ env('STRIPE_KEY') }}');

    // The items the customer wants to buy
    const items = [{ id: "xl-tshirt" }];

    let elements;

    initialize();
    checkStatus();

    document
      .querySelector("#payment-form")
      .addEventListener("submit", handleSubmit);

    // Fetches a payment intent and captures the client secret
    async function initialize() {
       const { clientSecret } = await fetch("/subscribes/payment-secret", {
        method: "POST",
        headers: { "Content-Type": "application/json", 'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content') },
        body: JSON.stringify({ items }),
      }).then((r) => r.json());

      elements = stripe.elements({ clientSecret });

      const paymentElementOptions = {
		layout: "tabs",
		payment_methods: [
		  {
			type: "card",
			card: {
			  iconStyle: "default",
			  hideIcon: false,
			  style: {
				base: {
				  iconColor: "#666EE8",
				  color: "#31325F",
				  fontWeight: 400,
				  fontFamily: "Arial, sans-serif",
				  fontSize: "16px",
				  fontSmoothing: "antialiased",
				  "::placeholder": {
					color: "#CFD7E0",
				  },
				},
			  },
			},
		  },
		  {
			type: "google_pay",
			style: {
			  base: {
				color: "#31325F",
				fontSize: "16px",
				"::placeholder": {
				  color: "#CFD7E0",
				},
			  },
			},
		  },
		],
	  };

      const paymentElement = elements.create("payment", paymentElementOptions);
      paymentElement.mount("#payment-element");
    }

    async function handleSubmit(e) {
      e.preventDefault();
      setLoading(true);

      const { error } = await stripe.confirmPayment({
        elements,
        confirmParams: {
          // Make sure to change this to your payment completion page
          return_url: "http://localhost/stripe-checkout/public/checkout.html",
        },
      });

      // This point will only be reached if there is an immediate error when
      // confirming the payment. Otherwise, your customer will be redirected to
      // your `return_url`. For some payment methods like iDEAL, your customer will
      // be redirected to an intermediate site first to authorize the payment, then
      // redirected to the `return_url`.
      if (error.type === "card_error" || error.type === "validation_error") {
        showMessage(error.message);
      } else {
        showMessage("An unexpected error occurred.");
      }

      setLoading(false);
    }

    // Fetches the payment intent status after payment submission
    async function checkStatus() {
      const clientSecret = new URLSearchParams(window.location.search).get(
        "payment_intent_client_secret"
      );

      if (!clientSecret) {
        return;
      }

      const { paymentIntent } = await stripe.retrievePaymentIntent(clientSecret);

      switch (paymentIntent.status) {
        case "succeeded":
          showMessage("Payment succeeded!");
          break;
        case "processing":
          showMessage("Your payment is processing.");
          break;
        case "requires_payment_method":
          showMessage("Your payment was not successful, please try again.");
          break;
        default:
          showMessage("Something went wrong.");
          break;
      }
    }

    // ------- UI helpers -------

    function showMessage(messageText) {
      const messageContainer = document.querySelector("#payment-message");

      messageContainer.classList.remove("hidden");
      messageContainer.textContent = messageText;

      setTimeout(function () {
        messageContainer.classList.add("hidden");
        messageContainer.textContent = "";
      }, 4000);
    }

    // Show a spinner on payment submission
    function setLoading(isLoading) {
      if (isLoading) {
        // Disable the button and show a spinner
        document.querySelector("#submit").disabled = true;
        document.querySelector("#spinner").classList.remove("hidden");
        document.querySelector("#button-text").classList.add("hidden");
      } else {
        document.querySelector("#submit").disabled = false;
        document.querySelector("#spinner").classList.add("hidden");
        document.querySelector("#button-text").classList.remove("hidden");
      }
    }
</script>